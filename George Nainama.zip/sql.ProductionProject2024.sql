DROP TABLE LE_Crime_fact CASCADE CONSTRAINTS;
DROP TABLE Time_dim CASCADE CONSTRAINTS;
DROP TABLE Crime_type_dim CASCADE CONSTRAINTS;
DROP TABLE Location_dim CASCADE CONSTRAINTS;
DROP TABLE Reporting_authority_dim CASCADE CONSTRAINTS;


-- Create a Database table to represent the "Crime_type_dim" entity.
CREATE TABLE Crime_type_dim (
    Crime_type_id INT NOT NULL,
    Crime_type VARCHAR(50),
CONSTRAINT pk_Crime_type_dim PRIMARY KEY (Crime_type_id)
);

-- Create a Database table to represent the "Location_dim" entity.
CREATE TABLE Location_dim (
    Location_id INT NOT NULL,
    City VARCHAR(30),
     Latitude DECIMAL(10, 8),
    Longitude DECIMAL(11, 8),
    CONSTRAINT pk_Location_dim PRIMARY KEY (Location_id)
);

-- Create a Database table to represent the "Reporting_authority_dim" entity.
CREATE TABLE Reporting_authority_dim (
    Reporting_authority_id INT NOT NULL,
    Police_force VARCHAR(30),
    CONSTRAINT pk_Reporting_authority_dim PRIMARY KEY (Reporting_authority_id)

);

-- Create a Database table to represent the "Crime_fact" entity.
CREATE TABLE LE_Crime_fact (
    Crime_id INT NOT NULL,
    Time_id INT NOT NULL,
    last_outcome VARCHAR(100),
    Location_id INT NOT NULL,
    Crime_type_id INT NOT NULL,
    Reporting_authority_id INT NOT NULL,
     CONSTRAINT pk_LE_Crime_fact PRIMARY KEY (Crime_id)
);

-- Create a Database table to represent the "Time_dim" entity.
CREATE TABLE Time_dim (
    Time_id INT NOT NULL,
    The_Year INT,
    CONSTRAINT pk_Time_dim PRIMARY KEY (Time_id)
);

ALTER TABLE LE_Crime_fact
ADD CONSTRAINT fk_LE_Crime_fact_Crime_type_dim
FOREIGN KEY (Crime_type_id)
REFERENCES Crime_type_dim(Crime_type_id);

ALTER TABLE LE_Crime_fact
ADD CONSTRAINT fk_LE_Crime_fact_Location_dim
FOREIGN KEY (Location_id)
REFERENCES Location_dim(Location_id);

ALTER TABLE LE_Crime_fact
ADD CONSTRAINT fk_LE_Crime_fact_Reporting_authority_dim
FOREIGN KEY (Reporting_authority_id)
REFERENCES Reporting_authority_dim(Reporting_authority_id);



DELETE FROM LE_Crime_fact;
DELETE FROM Reporting_authority_dim;
DELETE FROM Time_dim;
DELETE FROM Crime_type_dim;
DELETE FROM Location_dim;

INSERT INTO Time_dim VALUES (21,  2021);
INSERT INTO Time_dim VALUES (22,  2022);
INSERT INTO Time_dim VALUES (23,  2023);

INSERT INTO Location_dim VALUES (200, 'Liverpool', 53.473897, -2.92452);
INSERT INTO Location_dim VALUES (201, 'Bristol', 51.51307, -2.616959);
INSERT INTO Location_dim VALUES (202, 'Manchester', 53.497759, -2.175216);
INSERT INTO Location_dim VALUES (203, 'Birmingham', 52.593864, -1.847123);
INSERT INTO Location_dim VALUES (204, 'Leeds', 53.934176, -1.388079);
INSERT INTO Location_dim VALUES (205, 'London', 51.515387, -0.097245);
INSERT INTO Location_dim VALUES (207, 'Sheffield', 53.478492, -1.590501);
INSERT INTO Location_dim VALUES (209, 'Newcastle upon Tyne', 55.012253, -1.666861);



INSERT INTO Crime_type_dim VALUES (300, 'Anti-social behaviour' );
INSERT INTO Crime_type_dim VALUES (301, 'Bicycle theft');
INSERT INTO Crime_type_dim VALUES (302, 'Burglary');
INSERT INTO Crime_type_dim VALUES (303, 'Criminal damage and arson');
INSERT INTO Crime_type_dim VALUES (304, 'Drugs');
INSERT INTO Crime_type_dim VALUES (305, 'Other crime');
INSERT INTO Crime_type_dim VALUES (306, 'Other theft');
INSERT INTO Crime_type_dim VALUES (307, 'Possession of weapons');
INSERT INTO Crime_type_dim VALUES (308, 'Public order');
INSERT INTO Crime_type_dim VALUES (309, 'Robbery');
INSERT INTO Crime_type_dim VALUES (310, 'Shoplifting');
INSERT INTO Crime_type_dim VALUES (311, 'Theft from the person');
INSERT INTO Crime_type_dim VALUES (312, 'Vehicle crime');
INSERT INTO Crime_type_dim VALUES (313, 'Violence and sexual offences');


INSERT INTO Reporting_authority_dim VALUES (400, 'Merseyside Police');
INSERT INTO Reporting_authority_dim VALUES (401, 'Avon and Somerset Constabulary');
INSERT INTO Reporting_authority_dim VALUES (402, 'Greater Manchester Police');
INSERT INTO Reporting_authority_dim VALUES (403, 'West Yorkshire Police');
INSERT INTO Reporting_authority_dim VALUES (404, 'Metropolitan Police Service');
INSERT INTO Reporting_authority_dim VALUES (405, 'West Midlands Police');
INSERT INTO Reporting_authority_dim VALUES (406, 'Northumbria Police');
INSERT INTO Reporting_authority_dim VALUES (407, 'South Yorkshire Police');



--LIVERPOOL
INSERT INTO LE_Crime_fact VALUES (001, 2021, 'Investigation complete; no suspect identified', 200, 300, 400);
INSERT INTO LE_Crime_fact VALUES (002, 2022, 'Investigation complete; no suspect identified', 200, 302, 400); 
INSERT INTO LE_Crime_fact VALUES (003, 2023, 'Investigation complete; no suspect identified', 200, 303, 400); 
INSERT INTO LE_Crime_fact VALUES (004, 2022, 'Investigation complete; no suspect identified', 200, 308, 400);
INSERT INTO LE_Crime_fact VALUES (005, 2022, 'Unable to prosecute suspect', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (006, 2022, 'Unable to prosecute suspect', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (007, 2022, 'Investigation complete; no suspect identified', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (008, 2022, 'Unable to prosecute suspect', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (009, 2022, 'Unable to prosecute suspect', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (010, 2022, 'Unable to prosecute suspect', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (011, 2022, 'Investigation complete; no suspect identified', 200, 302, 400);
INSERT INTO LE_Crime_fact VALUES (012, 2022, 'Unable to prosecute suspect', 200, 303, 400);
INSERT INTO LE_Crime_fact VALUES (013, 2022, 'Investigation complete; no suspect identified', 200, 309, 400);
INSERT INTO LE_Crime_fact VALUES (014, 2022, 'Unable to prosecute suspect', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (015, 2022, 'Unable to prosecute suspect', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (016, 2022, 'Unable to prosecute suspect', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (017, 2021, 'Unable to prosecute suspect', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (018, 2022, 'Investigation complete; no suspect identified', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (019, 2022, 'Unable to prosecute suspect', 200, 313, 400);
INSERT INTO LE_Crime_fact VALUES (020, 2023, 'Further action is not in the public interest', 200, 305, 400);
INSERT INTO LE_Crime_fact VALUES (021, 2023, 'Unable to prosecute suspect', 200, 301, 400);
INSERT INTO LE_Crime_fact VALUES (022, 2023, 'Investigation complete; no suspect identified', 200, 303, 400);
INSERT INTO LE_Crime_fact VALUES (023, 2022, 'Unable to prosecute suspect', 200, 303, 400);
INSERT INTO LE_Crime_fact VALUES (024, 2023, 'Investigation complete; no suspect identified', 200, 306, 400);
INSERT INTO LE_Crime_fact VALUES (025, 2022, 'Unable to prosecute suspect', 200, 308, 400);
INSERT INTO LE_Crime_fact VALUES (026, 2023, 'Further investigation is not in the public interest', 200, 308, 400);
INSERT INTO LE_Crime_fact VALUES (027, 2021, 'Unable to prosecute suspect', 200, 308, 400);
INSERT INTO LE_Crime_fact VALUES (028, 2021, 'Unable to prosecute suspect', 200, 308, 400);
INSERT INTO LE_Crime_fact VALUES (029, 2021, 'Investigation complete; no suspect identified', 200, 308, 400);

-- BRISTOL
INSERT INTO LE_Crime_fact VALUES (030, 2023, 'Unable to prosecute suspect', 201, 302, 401);
INSERT INTO LE_Crime_fact VALUES (031, 2023, 'Status update unavailable', 201, 302, 401);
INSERT INTO LE_Crime_fact VALUES (032, 2023, 'Unable to prosecute suspect', 201, 303, 401);
INSERT INTO LE_Crime_fact VALUES (033, 2021, 'Unable to prosecute suspect', 201, 303, 401);
INSERT INTO LE_Crime_fact VALUES (034, 2022, 'Unable to prosecute suspect', 201, 306, 401);
INSERT INTO LE_Crime_fact VALUES (035, 2022, 'Court result unavailable', 201, 308, 401);
INSERT INTO LE_Crime_fact VALUES (036, 2023, 'Status update unavailable', 201, 310, 401);
INSERT INTO LE_Crime_fact VALUES (037, 2022, 'Status update unavailable', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (038, 2021, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (039, 2021, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (040, 2021, 'Awaiting court outcome', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (041, 2022, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (042, 2022, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (043, 2021, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (044, 2021, 'Status update unavailable', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (045, 2022, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (046, 2022, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (047, 2021, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (048, 2023, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (049, 2022, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (050, 2022, 'Status update unavailable', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (051, 2023, 'Status update unavailable', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (052, 2022, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (053, 2022, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (054, 2023, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (055, 2022, 'Status update unavailable', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (056, 2022, 'Investigation complete; no suspect identified', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (057, 2023, 'Unable to prosecute suspect', 201, 313, 401);
INSERT INTO LE_Crime_fact VALUES (058, 2021, 'Investigation complete; no suspect identified', 201, 313, 401);

-- LONDON
INSERT INTO LE_Crime_fact VALUES (059, 2023, 'Status update unavailable', 205, 306, 404);
INSERT INTO LE_Crime_fact VALUES (060, 2021, 'Investigation complete; no suspect identified', 205, 309, 404);
INSERT INTO LE_Crime_fact VALUES (061, 2023, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (062, 2022, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (063, 2023, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (064, 2022, 'Status update unavailable', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (065, 2022, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (066, 2022, 'Status update unavailable', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (067, 2023, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (068, 2022, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (069, 2023, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (070, 2023, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (071, 2023, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (072, 2022, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (073, 2022, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (074, 2021, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (075, 2021, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (076, 2021, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (077, 2022, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (078, 2022, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (079, 2022, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (080, 2022, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (081, 2021, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (082, 2022, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (083, 2022, 'Status update unavailable', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (084, 2021, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (085, 2022, 'Status update unavailable', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (086, 2022, 'Investigation complete; no suspect identified', 205, 311, 404);
INSERT INTO LE_Crime_fact VALUES (087, 2023, 'Investigation complete; no suspect identified', 205, 311, 404);

-- NEWCASTLE UPON TYNE
INSERT INTO LE_Crime_fact VALUES (088, 2022, 'Status update unavailable', 209, 313, 406);
INSERT INTO LE_Crime_fact VALUES (089, 2023, 'Status update unavailable', 209, 310, 406);
INSERT INTO LE_Crime_fact VALUES (090, 2023, 'Status update unavailable', 209, 312, 406);
INSERT INTO LE_Crime_fact VALUES (091, 2022, 'Status update unavailable', 209, 309, 406);
INSERT INTO LE_Crime_fact VALUES (092, 2022, 'Investigation complete; no suspect identified', 209, 304, 406);
INSERT INTO LE_Crime_fact VALUES (093, 2022, 'Status update unavailable', 209, 305, 406);
INSERT INTO LE_Crime_fact VALUES (094, 2022, 'Investigation complete; no suspect identified', 209, 308, 406);
INSERT INTO LE_Crime_fact VALUES (095, 2022, 'Investigation complete; no suspect identified', 209, 306, 406);
INSERT INTO LE_Crime_fact VALUES (097, 2022, 'Investigation complete; no suspect identified', 209, 307, 406);
INSERT INTO LE_Crime_fact VALUES (098, 2022, 'Status update unavailable', 209, 303, 406);
INSERT INTO LE_Crime_fact VALUES (099, 2022, 'Investigation complete; no suspect identified', 209, 301, 406);
INSERT INTO LE_Crime_fact VALUES (100, 2023, 'Investigation complete; no suspect identified', 209, 302, 406);
INSERT INTO LE_Crime_fact VALUES (101, 2023, 'Investigation complete; no suspect identified', 209, 304, 406);
INSERT INTO LE_Crime_fact VALUES (102, 2021, 'Investigation complete; no suspect identified', 209, 308, 406);
INSERT INTO LE_Crime_fact VALUES (103, 2021, 'Investigation complete; no suspect identified', 209, 310, 406);
INSERT INTO LE_Crime_fact VALUES (104, 2023, 'Status update unavailable', 209, 311, 406);
INSERT INTO LE_Crime_fact VALUES (105, 2022, 'Investigation complete; no suspect identified', 209, 305, 406);
INSERT INTO LE_Crime_fact VALUES (106, 2021, 'Investigation complete; no suspect identified', 209, 309, 406);
INSERT INTO LE_Crime_fact VALUES (107, 2023, 'Investigation complete; no suspect identified', 209, 312, 406);
INSERT INTO LE_Crime_fact VALUES (108, 2023, 'Status update unavailable', 209, 313, 406);
INSERT INTO LE_Crime_fact VALUES (109, 2023, 'Investigation complete; no suspect identified', 209, 302, 406);
INSERT INTO LE_Crime_fact VALUES (110, 2023, 'Investigation complete; no suspect identified', 209, 306, 406);
INSERT INTO LE_Crime_fact VALUES (111, 2021, 'Status update unavailable', 209, 301, 406);
INSERT INTO LE_Crime_fact VALUES (112, 2022, 'Status update unavailable', 209, 307, 406);
INSERT INTO LE_Crime_fact VALUES (113, 2022, 'Status update unavailable', 209, 303, 406);

--SHEFIELD
INSERT INTO LE_Crime_fact VALUES (114, 2022, 'Unable to prosecute suspect', 207, 302, 407);
INSERT INTO LE_Crime_fact VALUES (115, 2022, 'Status update unavailable', 207, 302, 407);
INSERT INTO LE_Crime_fact VALUES (116, 2023, 'Unable to prosecute suspect', 207, 303, 407);
INSERT INTO LE_Crime_fact VALUES (117, 2023, 'Unable to prosecute suspect', 207, 303, 407);
INSERT INTO LE_Crime_fact VALUES (118, 2022, 'Unable to prosecute suspect', 207, 306, 407);
INSERT INTO LE_Crime_fact VALUES (119, 2022, 'Court result unavailable', 207, 308, 407);
INSERT INTO LE_Crime_fact VALUES (120, 2022, 'Status update unavailable', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (121, 2022, 'Status update unavailable', 207, 313, 407);
INSERT INTO LE_Crime_fact VALUES (122, 2022, 'Investigation complete; no suspect identified', 207, 309, 407);
INSERT INTO LE_Crime_fact VALUES (123, 2022, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (124, 2022, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (125, 2022, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (126, 2022, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (127, 2023, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (128, 2022, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (129, 2021, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (130, 2022, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (131, 2021, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (132, 2023, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (133, 2023, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (134, 2023, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (135, 2021, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (136, 2021, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (137, 2022, 'Investigation complete; no suspect identified', 207, 310, 407);
INSERT INTO LE_Crime_fact VALUES (138, 2022, 'Investigation complete; no suspect identified', 207, 312, 407);
INSERT INTO LE_Crime_fact VALUES (139, 2022, 'Investigation complete; no suspect identified', 207, 312, 407);
INSERT INTO LE_Crime_fact VALUES (140, 2021, 'Investigation complete; no suspect identified', 207, 312, 407);
INSERT INTO LE_Crime_fact VALUES (141, 2022, 'Investigation complete; no suspect identified', 207, 313, 407);

-- BIRMINGHAM
INSERT INTO LE_Crime_fact VALUES (142, 2022, 'Investigation complete; no suspect identified', 203, 312, 405);
INSERT INTO LE_Crime_fact VALUES (143, 2022, 'Unable to prosecute suspect', 203, 313, 405);
INSERT INTO LE_Crime_fact VALUES (144, 2022, 'Unable to prosecute suspect', 203, 313, 405);
INSERT INTO LE_Crime_fact VALUES (145, 2021, 'Investigation complete; no suspect identified', 203, 308, 405);
INSERT INTO LE_Crime_fact VALUES (146, 2023, 'Unable to prosecute suspect', 203, 313, 405);
INSERT INTO LE_Crime_fact VALUES (147, 2022, 'Unable to prosecute suspect', 203, 313, 405);
INSERT INTO LE_Crime_fact VALUES (148, 2021, 'Unable to prosecute suspect', 203, 303, 405);
INSERT INTO LE_Crime_fact VALUES (149, 2022, 'Unable to prosecute suspect', 203, 303, 405);
INSERT INTO LE_Crime_fact VALUES (150, 2021, 'Unable to prosecute suspect', 203, 308, 405);
INSERT INTO LE_Crime_fact VALUES (151, 2023, 'Unable to prosecute suspect', 203, 313, 405);
INSERT INTO LE_Crime_fact VALUES (152, 2023, 'Investigation complete; no suspect identifed', 203, 309, 405);
INSERT INTO LE_Crime_fact VALUES (153, 2021, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (154, 2022, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (155, 2022, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (156, 2023, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (157, 2023, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (158, 2023, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (159, 2023, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (160, 2022, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (161, 2021, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (162, 2023, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (163, 2023, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (164, 2023, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (165, 2023, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (166, 2022, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (167, 2023, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (168, 2023, 'Investigation complete; no suspect identified', 203, 310, 405);
INSERT INTO LE_Crime_fact VALUES (169, 2023, 'Investigation complete; no suspect identified', 203, 310, 405);

-- LEEDS
INSERT INTO LE_Crime_fact VALUES (171, 2022, 'Investigation complete; no suspect identified', 204, 304, 403);
INSERT INTO LE_Crime_fact VALUES (172, 2022, 'Unable to prosecute suspect', 204, 304, 403);
INSERT INTO LE_Crime_fact VALUES (173, 2022, 'Investigation complete; no suspect identified', 204, 305, 403);
INSERT INTO LE_Crime_fact VALUES (174, 2022, 'Unable to prosecute suspect', 204, 305, 403);
INSERT INTO LE_Crime_fact VALUES (175, 2023, 'Unable to prosecute suspect', 204, 305, 403);
INSERT INTO LE_Crime_fact VALUES (176, 2023, 'Unable to prosecute suspect', 204, 305, 403);
INSERT INTO LE_Crime_fact VALUES (177, 2023, 'Unable to prosecute suspect', 204, 305, 403);
INSERT INTO LE_Crime_fact VALUES (178, 2021, 'Investigation complete; no suspect identified', 204, 306, 403);
INSERT INTO LE_Crime_fact VALUES (179, 2023, 'Unable to prosecute suspect', 204, 306, 403);
INSERT INTO LE_Crime_fact VALUES (180, 2023, 'Unable to prosecute suspect', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (181, 2023, 'Investigation complete; no suspect identified', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (182, 2023, 'Unable to prosecute suspect', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (183, 2023, 'Investigation complete; no suspect identified', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (184, 2023, 'Unable to prosecute suspect', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (185, 2023, 'Investigation complete; no suspect identified', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (186, 2023, 'Unable to prosecute suspect', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (187, 2023, 'Investigation complete; no suspect identified', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (188, 2023, 'Unable to prosecute suspect', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (189, 2023, 'Investigation complete; no suspect identified', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (190, 2022, 'Unable to prosecute suspect', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (191, 2022, 'Investigation complete; no suspect identified', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (192, 2023, 'Unable to prosecute suspect', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (193, 2023, 'Investigation complete; no suspect identified', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (194, 2023, 'Unable to prosecute suspect', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (195, 2023, 'Investigation complete; no suspect identified', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (196, 2021, 'Unable to prosecute suspect', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (197, 2022, 'Investigation complete; no suspect identified', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (198, 2022, 'Unable to prosecute suspect', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (199, 2022, 'Investigation complete; no suspect identified', 204, 307, 403);
INSERT INTO LE_Crime_fact VALUES (250, 2022, 'Unable to prosecute suspect', 204, 307, 403);

-- MANCHESTER
INSERT INTO LE_Crime_fact VALUES (251, 2022, 'Investigation complete; no suspect identified', 202, 301, 402);
INSERT INTO LE_Crime_fact VALUES (252, 2022, 'Unable to prosecute suspect', 202, 302, 402);
INSERT INTO LE_Crime_fact VALUES (253, 2022, 'Investigation complete; no suspect identified', 202, 303, 402);
INSERT INTO LE_Crime_fact VALUES (254, 2022, 'Unable to prosecute suspect', 202, 304, 402);
INSERT INTO LE_Crime_fact VALUES (255, 2022, 'Investigation complete; no suspect identified', 202, 305, 402);
INSERT INTO LE_Crime_fact VALUES (256, 2021, 'Unable to prosecute suspect', 202, 306, 402);
INSERT INTO LE_Crime_fact VALUES (257, 2022, 'Investigation complete; no suspect identified', 202, 307, 402);
INSERT INTO LE_Crime_fact VALUES (258, 2021, 'Unable to prosecute suspect', 202, 308, 402);
INSERT INTO LE_Crime_fact VALUES (259, 2022, 'Investigation complete; no suspect identified', 202, 309, 402);
INSERT INTO LE_Crime_fact VALUES (260, 2021, 'Unable to prosecute suspect', 202, 310, 402);
INSERT INTO LE_Crime_fact VALUES (261, 2022, 'Investigation complete; no suspect identified', 202, 311, 402);
INSERT INTO LE_Crime_fact VALUES (262, 2022, 'Unable to prosecute suspect', 202, 312, 402);
INSERT INTO LE_Crime_fact VALUES (263, 2022, 'Investigation complete; no suspect identified', 202, 313, 402);
INSERT INTO LE_Crime_fact VALUES (264, 2023, 'Unable to prosecute suspect', 202, 302, 402);
INSERT INTO LE_Crime_fact VALUES (265, 2023, 'Investigation complete; no suspect identified', 202, 310, 402);
INSERT INTO LE_Crime_fact VALUES (266, 2022, 'Unable to prosecute suspect', 202, 302, 402);
INSERT INTO LE_Crime_fact VALUES (267, 2023, 'Investigation complete; no suspect identified', 202, 310, 402);
INSERT INTO LE_Crime_fact VALUES (268, 2023, 'Unable to prosecute suspect', 202, 301, 402);
INSERT INTO LE_Crime_fact VALUES (269, 2022, 'Investigation complete; no suspect identified', 202, 309, 402);
INSERT INTO LE_Crime_fact VALUES (270, 2022, 'Unable to prosecute suspect', 202, 301, 402);
INSERT INTO LE_Crime_fact VALUES (271, 2021, 'Investigation complete; no suspect identified', 202, 309, 402);
INSERT INTO LE_Crime_fact VALUES (272, 2022, 'Unable to prosecute suspect', 202, 305, 402);
INSERT INTO LE_Crime_fact VALUES (273, 2023, 'Investigation complete; no suspect identified', 202, 309, 402);
INSERT INTO LE_Crime_fact VALUES (274, 2022, 'Unable to prosecute suspect', 202, 302, 402);
INSERT INTO LE_Crime_fact VALUES (275, 2022, 'Investigation complete; no suspect identified', 202, 306, 402);
INSERT INTO LE_Crime_fact VALUES (276, 2022, 'Unable to prosecute suspect', 202, 310, 402);
INSERT INTO LE_Crime_fact VALUES (277, 2022, 'Investigation complete; no suspect identified', 202, 306, 402);
INSERT INTO LE_Crime_fact VALUES (278, 2022, 'Unable to prosecute suspect', 202, 306, 402);
INSERT INTO LE_Crime_fact VALUES (279, 2022, 'Investigation complete; no suspect identified', 202, 309, 402);


--------------------------------DROP TRIG------------------------------
DROP TRIGGER log_id_trigger;
-----------------------------------------------------------------------
DROP TABLE Crime_log CASCADE CONSTRAINTS; 
-------------------------DROP SEQ--------------------------------------         
DROP SEQUENCE log_id_seq;
-----------------------------------------------------------------------
CREATE SEQUENCE log_id_seq START WITH 1 INCREMENT BY 1;
--------------------------------------------------------------------------------------------------------------------
CREATE TABLE Crime_log (
    log_id NUMBER,
    related_crime_id INT, 
    action_performed VARCHAR2(30),
    action_date DATE,
    CONSTRAINT crime_log_pk PRIMARY KEY (log_id),
    CONSTRAINT fk_related_crime_id FOREIGN KEY (related_crime_id) REFERENCES LE_Crime_fact(Crime_id)
);
-------------------------------------------------------------------------------------------------------------------
-- PL/SQL Procedure to Update Crime Status
CREATE OR REPLACE PROCEDURE update_crime_status (
    p_crime_id IN NUMBER,
    p_new_status IN VARCHAR2
) AS
BEGIN
    UPDATE LE_Crime_fact
    SET last_outcome = p_new_status
    WHERE crime_id = p_crime_id;
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Crime status updated successfully.');
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Crime ID ' || p_crime_id || ' not found.');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('An error occurred while updating the crime status.');
END;
/

-- Trigger to Log Changes in Crime Fact Table
CREATE OR REPLACE TRIGGER log_LEcrime_changes
AFTER INSERT OR UPDATE OR DELETE ON LE_Crime_fact
FOR EACH ROW
DECLARE
    v_action VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_action := 'INSERT';
    ELSIF UPDATING THEN
        v_action := 'UPDATE';
    ELSIF DELETING THEN
        v_action := 'DELETE';
    END IF;
    
    INSERT INTO Crime_log (related_crime_id, action_performed, action_date)
    VALUES (:NEW.Crime_id, v_action, SYSDATE);
END;
/

-- Trigger--
CREATE OR REPLACE TRIGGER log_id_trigger
BEFORE INSERT ON Crime_log
FOR EACH ROW
BEGIN
    SELECT log_id_seq.NEXTVAL INTO :NEW.LOG_ID FROM dual;
END;
/
----------------------------------------------------------------------
DROP TABLE pr_PREDICTION_INPUT CASCADE CONSTRAINTS;
DROP TABLE pr_PREDICTION_RESULT CASCADE CONSTRAINTS;
DROP PACKAGE ml_operations_pkg;

----------------------------------------------------------------------
CREATE TABLE pr_PREDICTION_INPUT (
    Crime_id INT,
    Time_id INT,
    Location_id INT,
    Crime_type_id INT,
    Reporting_authority_id INT
);
CREATE TABLE pr_PREDICTION_RESULT (
    Crime_id INT,
    predicted_outcome NUMBER
);

ALTER TABLE pr_PREDICTION_INPUT
ADD CONSTRAINT unique_prediction_input
UNIQUE (Crime_id, Time_id, Location_id, Crime_type_id, Reporting_authority_id);

CREATE OR REPLACE PACKAGE ml_operations_pkg AS
  PROCEDURE train_linear_regression_model(p_model_name IN VARCHAR2);
  FUNCTION predict_linear_regression(crime_id IN INT, model_name IN VARCHAR2) RETURN NUMBER;
END ml_operations_pkg;
/

CREATE OR REPLACE PACKAGE BODY ml_operations_pkg AS
  PROCEDURE train_linear_regression_model(p_model_name IN VARCHAR2) AS
  BEGIN
    -- OML Model Training
    DBMS_DATA_MINING.CREATE_MODEL(
        model_name => p_model_name,
        mining_function => DBMS_DATA_MINING.REGRESSION,
        data_table_name => 'LE_Crime_fact',
        case_id_column_name => 'Crime_id',  
        target_column_name => 'last_outcome',  
        settings_table_name => NULL  
    );
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Error occurred during model training: ' || SQLERRM);
  END train_linear_regression_model;

  FUNCTION predict_linear_regression(crime_id IN INT, model_name IN VARCHAR2) RETURN NUMBER AS
    v_prediction NUMBER;
  BEGIN
    -- Prepare data for prediction
    INSERT INTO pr_PREDICTION_INPUT (Crime_id, Time_id, Location_id, Crime_type_id, Reporting_authority_id)
    SELECT Crime_id, Time_id, Location_id, Crime_type_id, Reporting_authority_id
    FROM LE_Crime_fact
    WHERE Crime_id = crime_id;

    -- Apply the model to the prepared data
    DBMS_DATA_MINING.APPLY(
        model_name => model_name,
        data_table_name => 'pr_PREDICTION_INPUT',
        case_id_column_name => 'Crime_id',
        result_table_name => 'pr_PREDICTION_RESULT'
    );

   -- Retrieve the prediction
    BEGIN
      SELECT predicted_outcome INTO v_prediction 
      FROM pr_PREDICTION_RESULT 
      WHERE Crime_id = crime_id;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No prediction found for the given crime ID.');
        RETURN NULL;
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error occurred during prediction: ' || SQLERRM);
        RETURN NULL;
    END;

    RETURN v_prediction;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Error occurred during prediction: ' || SQLERRM);
      RETURN NULL; 
  END predict_linear_regression;
END ml_operations_pkg;
/
BEGIN
  ml_operations_pkg.train_linear_regression_model('CRIME_PREDICTION_MODEL');
END;
/
